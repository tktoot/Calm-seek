"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Heart, Calendar, MapPin, Settings, Plus } from "lucide-react"
import { mockVenues, mockEvents } from "@/lib/mock-data"

export default function ProfilePage() {
  // Mock user data - would come from auth in production
  const savedVenues = mockVenues.slice(0, 2)
  const upcomingEvents = mockEvents.slice(0, 1)

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="mb-2 text-4xl font-bold tracking-tight text-foreground">My Profile</h1>
          <p className="text-lg text-muted-foreground">Manage your saved venues and upcoming events</p>
        </div>
        <Button variant="outline" size="sm" className="gap-2 bg-transparent">
          <Settings className="h-4 w-4" />
          Settings
        </Button>
      </div>

      <Tabs defaultValue="favorites" className="space-y-6">
        <TabsList className="grid w-full max-w-md grid-cols-3">
          <TabsTrigger value="favorites" className="gap-2">
            <Heart className="h-4 w-4" />
            Favorites
          </TabsTrigger>
          <TabsTrigger value="events" className="gap-2">
            <Calendar className="h-4 w-4" />
            Events
          </TabsTrigger>
          <TabsTrigger value="submitted" className="gap-2">
            <Plus className="h-4 w-4" />
            Submitted
          </TabsTrigger>
        </TabsList>

        <TabsContent value="favorites" className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-semibold">Saved Venues</h2>
            <Badge variant="secondary">{savedVenues.length} venues</Badge>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            {savedVenues.map((venue) => (
              <Card key={venue.id}>
                <div className="relative aspect-video overflow-hidden rounded-t-lg">
                  <img
                    src={venue.imageUrl || "/placeholder.svg"}
                    alt={venue.name}
                    className="h-full w-full object-cover"
                  />
                </div>
                <CardHeader>
                  <CardTitle className="text-lg">{venue.name}</CardTitle>
                  <CardDescription className="flex items-center gap-1">
                    <MapPin className="h-3 w-3" />
                    {venue.city}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex gap-2">
                    <Button className="flex-1" asChild>
                      <a href={`/venues/${venue.id}`}>View Details</a>
                    </Button>
                    <Button variant="outline" size="icon">
                      <Heart className="h-4 w-4 fill-current" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {savedVenues.length === 0 && (
            <Card>
              <CardContent className="flex h-48 flex-col items-center justify-center gap-3 p-6">
                <Heart className="h-12 w-12 text-muted-foreground" />
                <p className="text-center text-muted-foreground">
                  No saved venues yet. Start exploring and save your favorites!
                </p>
                <Button asChild>
                  <a href="/">Browse Venues</a>
                </Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="events" className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-semibold">Upcoming Events</h2>
            <Badge variant="secondary">{upcomingEvents.length} registered</Badge>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            {upcomingEvents.map((event) => (
              <Card key={event.id}>
                <div className="relative aspect-video overflow-hidden rounded-t-lg">
                  <img
                    src={event.imageUrl || "/placeholder.svg"}
                    alt={event.name}
                    className="h-full w-full object-cover"
                  />
                </div>
                <CardHeader>
                  <CardTitle className="text-lg">{event.name}</CardTitle>
                  <CardDescription className="space-y-1">
                    <div className="flex items-center gap-1 text-sm">
                      <Calendar className="h-3 w-3" />
                      {new Date(event.date).toLocaleDateString("en-US", {
                        weekday: "short",
                        month: "short",
                        day: "numeric",
                      })}
                    </div>
                    <div className="flex items-center gap-1 text-sm">
                      <MapPin className="h-3 w-3" />
                      {event.venueName}
                    </div>
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Button className="w-full bg-transparent" variant="outline">
                    View Event Details
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>

          {upcomingEvents.length === 0 && (
            <Card>
              <CardContent className="flex h-48 flex-col items-center justify-center gap-3 p-6">
                <Calendar className="h-12 w-12 text-muted-foreground" />
                <p className="text-center text-muted-foreground">
                  No upcoming events. Browse events to find something that interests you!
                </p>
                <Button asChild>
                  <a href="/events">Browse Events</a>
                </Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="submitted" className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-semibold">Your Submissions</h2>
            <Button className="gap-2">
              <Plus className="h-4 w-4" />
              Submit Venue
            </Button>
          </div>

          <Card>
            <CardContent className="flex h-48 flex-col items-center justify-center gap-3 p-6">
              <Plus className="h-12 w-12 text-muted-foreground" />
              <p className="text-center text-muted-foreground">
                You haven't submitted any venues yet. Help the community by sharing sensory-friendly places you know!
              </p>
              <Button>Submit Your First Venue</Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
