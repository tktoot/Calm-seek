"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { MapPin, Star, Volume2, Sun, Users, Search, Map, List, Calendar, Clock, ArrowRight } from "lucide-react"
import { mockVenues, mockEvents } from "@/lib/mock-data"
import Link from "next/link"

export default function HomePage() {
  const [viewMode, setViewMode] = useState<"list" | "map">("list")
  const [searchQuery, setSearchQuery] = useState("")

  const filteredVenues = mockVenues.filter(
    (venue) =>
      venue.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      venue.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
      venue.tags.some((tag) => tag.toLowerCase().includes(searchQuery.toLowerCase())),
  )

  const getSensoryIcon = (type: string) => {
    switch (type) {
      case "noise":
        return <Volume2 className="h-3 w-3" />
      case "light":
        return <Sun className="h-3 w-3" />
      case "crowd":
        return <Users className="h-3 w-3" />
      default:
        return null
    }
  }

  const upcomingEvents = mockEvents.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()).slice(0, 3)

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Hero Section */}
      <div className="mb-8 text-center">
        <h1 className="mb-3 text-4xl font-bold tracking-tight text-foreground text-balance">Find Your Calm Space</h1>
        <p className="mx-auto max-w-2xl text-lg text-muted-foreground text-pretty">
          Discover sensory-friendly venues and events tailored for neurodivergent individuals. Filter by noise level,
          lighting, and crowd density.
        </p>
      </div>

      <Card className="mb-8 border-primary/20 bg-gradient-to-br from-primary/5 to-secondary/5">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-2xl text-balance">Upcoming Events Near You</CardTitle>
              <CardDescription className="mt-1">Sensory-friendly experiences happening soon</CardDescription>
            </div>
            <Link href="/events">
              <Button variant="ghost" size="sm" className="gap-2">
                View All
                <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-3">
            {upcomingEvents.map((event) => (
              <Card key={event.id} className="group transition-all hover:shadow-md">
                <div className="relative aspect-video overflow-hidden rounded-t-lg">
                  <img
                    src={event.imageUrl || "/placeholder.svg"}
                    alt={event.name}
                    className="h-full w-full object-cover transition-transform group-hover:scale-105"
                  />
                </div>
                <CardHeader className="pb-3">
                  <CardTitle className="text-base text-balance">{event.name}</CardTitle>
                  <CardDescription className="flex items-center gap-1 text-xs">
                    <MapPin className="h-3 w-3" />
                    {event.venueName}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-3 pt-0">
                  <div className="flex items-center gap-3 text-sm text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <Calendar className="h-3 w-3" />
                      {new Date(event.date).toLocaleDateString("en-US", { month: "short", day: "numeric" })}
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      {event.time}
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    <Badge variant="outline" className="gap-1 text-xs">
                      {getSensoryIcon("noise")}
                      {event.sensoryAttributes.noiseLevel}
                    </Badge>
                    <Badge variant="outline" className="gap-1 text-xs">
                      {getSensoryIcon("crowd")}
                      {event.sensoryAttributes.crowdDensity}
                    </Badge>
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {event.registered}/{event.capacity} registered
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Search and Filters */}
      <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            type="text"
            placeholder="Search venues by name, category, or tags..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
        <div className="flex gap-2">
          <Button
            variant={viewMode === "list" ? "secondary" : "outline"}
            size="sm"
            onClick={() => setViewMode("list")}
            className="gap-2"
          >
            <List className="h-4 w-4" />
            List
          </Button>
          <Button
            variant={viewMode === "map" ? "secondary" : "outline"}
            size="sm"
            onClick={() => setViewMode("map")}
            className="gap-2"
          >
            <Map className="h-4 w-4" />
            Map
          </Button>
        </div>
      </div>

      {/* View Mode Content */}
      {viewMode === "map" ? (
        <Card className="mb-6">
          <CardContent className="flex h-96 items-center justify-center p-6">
            <div className="text-center">
              <Map className="mx-auto mb-3 h-12 w-12 text-muted-foreground" />
              <p className="text-muted-foreground">Map view requires Mapbox integration. Showing list view for now.</p>
            </div>
          </CardContent>
        </Card>
      ) : null}

      {/* Venues List */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {filteredVenues.map((venue) => (
          <Link key={venue.id} href={`/venues/${venue.id}`}>
            <Card className="group h-full transition-all hover:shadow-lg">
              <div className="relative aspect-video overflow-hidden rounded-t-lg">
                <img
                  src={venue.imageUrl || "/placeholder.svg"}
                  alt={venue.name}
                  className="h-full w-full object-cover transition-transform group-hover:scale-105"
                />
                <Badge className="absolute right-3 top-3 bg-card/90 text-card-foreground backdrop-blur">
                  {venue.category}
                </Badge>
              </div>
              <CardHeader>
                <div className="flex items-start justify-between gap-2">
                  <CardTitle className="text-lg text-balance">{venue.name}</CardTitle>
                  <div className="flex items-center gap-1 text-sm font-medium">
                    <Star className="h-4 w-4 fill-accent text-accent" />
                    {venue.rating}
                  </div>
                </div>
                <CardDescription className="flex items-center gap-1 text-sm">
                  <MapPin className="h-3 w-3" />
                  {venue.city}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="mb-4 text-sm text-muted-foreground line-clamp-2">{venue.description}</p>

                {/* Sensory Attributes */}
                <div className="mb-3 flex flex-wrap gap-2">
                  <Badge variant="outline" className="gap-1 text-xs">
                    {getSensoryIcon("noise")}
                    {venue.sensoryAttributes.noiseLevel}
                  </Badge>
                  <Badge variant="outline" className="gap-1 text-xs">
                    {getSensoryIcon("light")}
                    {venue.sensoryAttributes.lighting}
                  </Badge>
                  <Badge variant="outline" className="gap-1 text-xs">
                    {getSensoryIcon("crowd")}
                    {venue.sensoryAttributes.crowdDensity}
                  </Badge>
                </div>

                {/* Tags */}
                <div className="flex flex-wrap gap-1">
                  {venue.tags.slice(0, 3).map((tag) => (
                    <Badge key={tag} variant="secondary" className="text-xs">
                      {tag}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>

      {filteredVenues.length === 0 && (
        <Card>
          <CardContent className="flex h-48 items-center justify-center p-6">
            <p className="text-muted-foreground">No venues found matching your search. Try different keywords.</p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
