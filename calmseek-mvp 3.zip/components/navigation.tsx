"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Button } from "@/components/ui/button"
import { MapPin, Calendar, User, Search, Shield } from "lucide-react"

export function Navigation() {
  const pathname = usePathname()

  const navItems = [
    { href: "/", label: "Venues", icon: MapPin },
    { href: "/events", label: "Events", icon: Calendar },
    { href: "/profile", label: "Profile", icon: User },
  ]

  const isAdminPage = pathname?.startsWith("/admin")

  return (
    <nav className="sticky top-0 z-50 border-b border-border bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/80">
      <div className="container mx-auto px-4">
        <div className="flex h-16 items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary">
              <MapPin className="h-5 w-5 text-primary-foreground" />
            </div>
            <span className="text-xl font-semibold text-foreground">CalmSeek</span>
          </Link>

          <div className="hidden md:flex items-center gap-1">
            {navItems.map((item) => {
              const Icon = item.icon
              const isActive = pathname === item.href
              return (
                <Button key={item.href} asChild variant={isActive ? "secondary" : "ghost"} className="gap-2">
                  <Link href={item.href}>
                    <Icon className="h-4 w-4" />
                    {item.label}
                  </Link>
                </Button>
              )
            })}
            <Button asChild variant={isAdminPage ? "secondary" : "ghost"} className="gap-2">
              <Link href="/admin">
                <Shield className="h-4 w-4" />
                Admin
              </Link>
            </Button>
          </div>

          <Button variant="outline" size="sm" className="gap-2 bg-transparent">
            <Search className="h-4 w-4" />
            <span className="hidden sm:inline">Search</span>
          </Button>
        </div>

        {/* Mobile navigation */}
        <div className="flex md:hidden border-t border-border">
          {navItems.map((item) => {
            const Icon = item.icon
            const isActive = pathname === item.href
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`flex flex-1 flex-col items-center gap-1 py-3 text-xs transition-colors ${
                  isActive ? "text-primary font-medium" : "text-muted-foreground hover:text-foreground"
                }`}
              >
                <Icon className="h-5 w-5" />
                {item.label}
              </Link>
            )
          })}
          <Link
            href="/admin"
            className={`flex flex-1 flex-col items-center gap-1 py-3 text-xs transition-colors ${
              isAdminPage ? "text-primary font-medium" : "text-muted-foreground hover:text-foreground"
            }`}
          >
            <Shield className="h-5 w-5" />
            Admin
          </Link>
        </div>
      </div>
    </nav>
  )
}
