export interface SensoryAttributes {
  noiseLevel: "quiet" | "moderate" | "loud"
  lighting: "dim" | "natural" | "bright"
  crowdDensity: "low" | "medium" | "high"
  hasQuietSpace: boolean
  wheelchairAccessible: boolean
  sensoryFriendlyHours: boolean
}

export interface Venue {
  id: string
  name: string
  category: string
  description: string
  address: string
  city: string
  coordinates: { lat: number; lng: number }
  sensoryAttributes: SensoryAttributes
  rating: number
  reviewCount: number
  imageUrl: string
  tags: string[]
}

export interface Event {
  id: string
  name: string
  venueId: string
  venueName: string
  date: string
  time: string
  description: string
  sensoryAttributes: SensoryAttributes
  capacity: number
  registered: number
  imageUrl: string
  tags: string[]
}

export interface VenueSubmission {
  id: string
  venue: Omit<Venue, "id">
  submittedBy: string
  submittedAt: string
  status: "pending" | "approved" | "rejected"
  reviewedBy?: string
  reviewedAt?: string
  reviewNotes?: string
}

export const mockVenues: Venue[] = [
  {
    id: "1",
    name: "Quiet Corner Cafe",
    category: "Cafe",
    description: "A peaceful cafe with soft lighting and comfortable seating. Perfect for a calm coffee break.",
    address: "123 Peaceful St",
    city: "San Francisco",
    coordinates: { lat: 37.7749, lng: -122.4194 },
    sensoryAttributes: {
      noiseLevel: "quiet",
      lighting: "dim",
      crowdDensity: "low",
      hasQuietSpace: true,
      wheelchairAccessible: true,
      sensoryFriendlyHours: true,
    },
    rating: 4.8,
    reviewCount: 124,
    imageUrl: "/cozy-quiet-cafe-interior.jpg",
    tags: ["Quiet", "Wheelchair Accessible", "Sensory-Friendly Hours"],
  },
  {
    id: "2",
    name: "Botanical Gardens",
    category: "Park",
    description: "Serene outdoor space with winding paths and beautiful plant collections.",
    address: "456 Garden Ave",
    city: "San Francisco",
    coordinates: { lat: 37.7699, lng: -122.4683 },
    sensoryAttributes: {
      noiseLevel: "quiet",
      lighting: "natural",
      crowdDensity: "low",
      hasQuietSpace: true,
      wheelchairAccessible: true,
      sensoryFriendlyHours: false,
    },
    rating: 4.9,
    reviewCount: 287,
    imageUrl: "/peaceful-botanical-garden.jpg",
    tags: ["Outdoor", "Nature", "Quiet"],
  },
  {
    id: "3",
    name: "City Library - Reading Room",
    category: "Library",
    description: "Dedicated quiet reading space with natural light and comfortable chairs.",
    address: "789 Book Blvd",
    city: "San Francisco",
    coordinates: { lat: 37.7799, lng: -122.415 },
    sensoryAttributes: {
      noiseLevel: "quiet",
      lighting: "natural",
      crowdDensity: "low",
      hasQuietSpace: true,
      wheelchairAccessible: true,
      sensoryFriendlyHours: true,
    },
    rating: 4.7,
    reviewCount: 156,
    imageUrl: "/quiet-library-reading-room.jpg",
    tags: ["Quiet", "Indoor", "Free"],
  },
  {
    id: "4",
    name: "Mindful Art Gallery",
    category: "Museum",
    description: "Small gallery with controlled lighting and spacious layout. Offers sensory-friendly viewing hours.",
    address: "321 Art Lane",
    city: "San Francisco",
    coordinates: { lat: 37.7849, lng: -122.4094 },
    sensoryAttributes: {
      noiseLevel: "quiet",
      lighting: "dim",
      crowdDensity: "low",
      hasQuietSpace: true,
      wheelchairAccessible: true,
      sensoryFriendlyHours: true,
    },
    rating: 4.6,
    reviewCount: 89,
    imageUrl: "/calm-art-gallery-interior.jpg",
    tags: ["Art", "Sensory-Friendly Hours", "Quiet"],
  },
  {
    id: "5",
    name: "Sunset Beach Trail",
    category: "Park",
    description: "Peaceful coastal walking trail with ocean views and minimal crowds.",
    address: "555 Coastal Hwy",
    city: "San Francisco",
    coordinates: { lat: 37.7599, lng: -122.51 },
    sensoryAttributes: {
      noiseLevel: "moderate",
      lighting: "natural",
      crowdDensity: "low",
      hasQuietSpace: true,
      wheelchairAccessible: false,
      sensoryFriendlyHours: false,
    },
    rating: 4.9,
    reviewCount: 342,
    imageUrl: "/peaceful-beach-trail.jpg",
    tags: ["Outdoor", "Nature", "Free"],
  },
]

export const mockEvents: Event[] = [
  {
    id: "1",
    name: "Morning Meditation Session",
    venueId: "2",
    venueName: "Botanical Gardens",
    date: "2025-10-05",
    time: "08:00 AM",
    description: "Guided meditation in the peaceful garden setting. Limited to 15 participants.",
    sensoryAttributes: {
      noiseLevel: "quiet",
      lighting: "natural",
      crowdDensity: "low",
      hasQuietSpace: true,
      wheelchairAccessible: true,
      sensoryFriendlyHours: true,
    },
    capacity: 15,
    registered: 8,
    imageUrl: "/outdoor-meditation-garden.jpg",
    tags: ["Meditation", "Outdoor", "Small Group"],
  },
  {
    id: "2",
    name: "Quiet Book Club",
    venueId: "3",
    venueName: "City Library - Reading Room",
    date: "2025-10-08",
    time: "06:00 PM",
    description: "Low-key book discussion with optional participation. Comfortable seating and dim lighting.",
    sensoryAttributes: {
      noiseLevel: "quiet",
      lighting: "dim",
      crowdDensity: "low",
      hasQuietSpace: true,
      wheelchairAccessible: true,
      sensoryFriendlyHours: true,
    },
    capacity: 12,
    registered: 7,
    imageUrl: "/cozy-book-club-meeting.jpg",
    tags: ["Books", "Social", "Small Group"],
  },
  {
    id: "3",
    name: "Sensory-Friendly Gallery Tour",
    venueId: "4",
    venueName: "Mindful Art Gallery",
    date: "2025-10-12",
    time: "10:00 AM",
    description: "Private gallery tour with reduced lighting and no crowds. Self-paced exploration encouraged.",
    sensoryAttributes: {
      noiseLevel: "quiet",
      lighting: "dim",
      crowdDensity: "low",
      hasQuietSpace: true,
      wheelchairAccessible: true,
      sensoryFriendlyHours: true,
    },
    capacity: 10,
    registered: 5,
    imageUrl: "/art-gallery-private-tour.jpg",
    tags: ["Art", "Sensory-Friendly", "Small Group"],
  },
]

export const mockSubmissions: VenueSubmission[] = [
  {
    id: "sub-1",
    venue: {
      name: "Tranquil Tea House",
      category: "Cafe",
      description: "A peaceful tea house with private booths and soft ambient music. Perfect for quiet conversations.",
      address: "789 Zen Street",
      city: "San Francisco",
      coordinates: { lat: 37.7649, lng: -122.4294 },
      sensoryAttributes: {
        noiseLevel: "quiet",
        lighting: "dim",
        crowdDensity: "low",
        hasQuietSpace: true,
        wheelchairAccessible: true,
        sensoryFriendlyHours: true,
      },
      rating: 0,
      reviewCount: 0,
      imageUrl: "/tranquil-tea-house.jpg",
      tags: ["Quiet", "Tea", "Private Booths"],
    },
    submittedBy: "user@example.com",
    submittedAt: "2025-09-28T14:30:00Z",
    status: "pending",
  },
  {
    id: "sub-2",
    venue: {
      name: "Mindful Yoga Studio",
      category: "Wellness",
      description: "Small yoga studio with gentle classes and calming atmosphere. Maximum 8 people per class.",
      address: "456 Wellness Way",
      city: "San Francisco",
      coordinates: { lat: 37.7749, lng: -122.4294 },
      sensoryAttributes: {
        noiseLevel: "quiet",
        lighting: "dim",
        crowdDensity: "low",
        hasQuietSpace: true,
        wheelchairAccessible: false,
        sensoryFriendlyHours: true,
      },
      rating: 0,
      reviewCount: 0,
      imageUrl: "/mindful-yoga-studio.jpg",
      tags: ["Yoga", "Wellness", "Small Groups"],
    },
    submittedBy: "wellness@example.com",
    submittedAt: "2025-09-27T10:15:00Z",
    status: "pending",
  },
  {
    id: "sub-3",
    venue: {
      name: "Cozy Corner Bookshop",
      category: "Bookstore",
      description: "Independent bookstore with reading nooks and quiet browsing areas.",
      address: "321 Book Lane",
      city: "San Francisco",
      coordinates: { lat: 37.7699, lng: -122.4194 },
      sensoryAttributes: {
        noiseLevel: "quiet",
        lighting: "natural",
        crowdDensity: "low",
        hasQuietSpace: true,
        wheelchairAccessible: true,
        sensoryFriendlyHours: false,
      },
      rating: 0,
      reviewCount: 0,
      imageUrl: "/cozy-bookshop.jpg",
      tags: ["Books", "Quiet", "Reading"],
    },
    submittedBy: "bookworm@example.com",
    submittedAt: "2025-09-26T16:45:00Z",
    status: "approved",
    reviewedBy: "admin@calmseek.com",
    reviewedAt: "2025-09-27T09:00:00Z",
    reviewNotes: "Great addition to our cafe listings!",
  },
]
