"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { MapPin, Users, Calendar, AlertCircle, CheckCircle, XCircle } from "lucide-react"
import { mockVenues, mockEvents, mockSubmissions } from "@/lib/mock-data"

export default function AdminDashboard() {
  const [submissions] = useState(mockSubmissions)

  const stats = {
    totalVenues: mockVenues.length,
    totalEvents: mockEvents.length,
    pendingSubmissions: submissions.filter((s) => s.status === "pending").length,
    approvedToday: submissions.filter(
      (s) =>
        s.status === "approved" && s.reviewedAt && new Date(s.reviewedAt).toDateString() === new Date().toDateString(),
    ).length,
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="mb-2 text-4xl font-bold tracking-tight text-foreground">Admin Dashboard</h1>
        <p className="text-lg text-muted-foreground">Manage venues, events, and moderate user submissions</p>
      </div>

      {/* Stats Overview */}
      <div className="mb-8 grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Venues</CardTitle>
            <MapPin className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalVenues}</div>
            <p className="text-xs text-muted-foreground">Active listings</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Events</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalEvents}</div>
            <p className="text-xs text-muted-foreground">Upcoming events</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Reviews</CardTitle>
            <AlertCircle className="h-4 w-4 text-accent" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.pendingSubmissions}</div>
            <p className="text-xs text-muted-foreground">Awaiting moderation</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Approved Today</CardTitle>
            <CheckCircle className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.approvedToday}</div>
            <p className="text-xs text-muted-foreground">New additions</p>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Tabs */}
      <Tabs defaultValue="moderation" className="space-y-6">
        <TabsList>
          <TabsTrigger value="moderation" className="gap-2">
            <AlertCircle className="h-4 w-4" />
            Moderation Queue
            {stats.pendingSubmissions > 0 && (
              <Badge variant="destructive" className="ml-1 h-5 px-1.5">
                {stats.pendingSubmissions}
              </Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="venues" className="gap-2">
            <MapPin className="h-4 w-4" />
            Venues
          </TabsTrigger>
          <TabsTrigger value="events" className="gap-2">
            <Calendar className="h-4 w-4" />
            Events
          </TabsTrigger>
        </TabsList>

        <TabsContent value="moderation" className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-semibold">Pending Submissions</h2>
            <Badge variant="secondary">{stats.pendingSubmissions} pending</Badge>
          </div>

          <div className="space-y-4">
            {submissions
              .filter((s) => s.status === "pending")
              .map((submission) => (
                <Card key={submission.id} className="border-l-4 border-l-accent">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="space-y-1">
                        <CardTitle className="text-xl">{submission.venue.name}</CardTitle>
                        <CardDescription className="flex items-center gap-4">
                          <span className="flex items-center gap-1">
                            <MapPin className="h-3 w-3" />
                            {submission.venue.city}
                          </span>
                          <span className="flex items-center gap-1">
                            <Users className="h-3 w-3" />
                            {submission.submittedBy}
                          </span>
                          <span className="text-xs">
                            {new Date(submission.submittedAt).toLocaleDateString("en-US", {
                              month: "short",
                              day: "numeric",
                              hour: "2-digit",
                              minute: "2-digit",
                            })}
                          </span>
                        </CardDescription>
                      </div>
                      <Badge>{submission.venue.category}</Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="relative aspect-video overflow-hidden rounded-lg">
                      <img
                        src={submission.venue.imageUrl || "/placeholder.svg"}
                        alt={submission.venue.name}
                        className="h-full w-full object-cover"
                      />
                    </div>

                    <p className="text-sm text-muted-foreground">{submission.venue.description}</p>

                    <div className="flex flex-wrap gap-2">
                      <Badge variant="outline" className="text-xs">
                        Noise: {submission.venue.sensoryAttributes.noiseLevel}
                      </Badge>
                      <Badge variant="outline" className="text-xs">
                        Light: {submission.venue.sensoryAttributes.lighting}
                      </Badge>
                      <Badge variant="outline" className="text-xs">
                        Crowd: {submission.venue.sensoryAttributes.crowdDensity}
                      </Badge>
                      {submission.venue.sensoryAttributes.wheelchairAccessible && (
                        <Badge variant="outline" className="text-xs">
                          Wheelchair Accessible
                        </Badge>
                      )}
                      {submission.venue.sensoryAttributes.sensoryFriendlyHours && (
                        <Badge variant="outline" className="text-xs">
                          Sensory-Friendly Hours
                        </Badge>
                      )}
                    </div>

                    <div className="flex gap-2">
                      <button className="flex-1 rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90">
                        <CheckCircle className="mr-2 inline-block h-4 w-4" />
                        Approve
                      </button>
                      <button className="flex-1 rounded-lg border border-border bg-transparent px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-muted">
                        <XCircle className="mr-2 inline-block h-4 w-4" />
                        Reject
                      </button>
                    </div>
                  </CardContent>
                </Card>
              ))}

            {stats.pendingSubmissions === 0 && (
              <Card>
                <CardContent className="flex h-48 flex-col items-center justify-center gap-3 p-6">
                  <CheckCircle className="h-12 w-12 text-primary" />
                  <p className="text-center text-muted-foreground">All caught up! No pending submissions to review.</p>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Recent Activity */}
          <div className="mt-8">
            <h3 className="mb-4 text-xl font-semibold">Recent Activity</h3>
            <div className="space-y-3">
              {submissions
                .filter((s) => s.status !== "pending")
                .slice(0, 5)
                .map((submission) => (
                  <Card key={submission.id}>
                    <CardContent className="flex items-center justify-between p-4">
                      <div className="flex items-center gap-3">
                        {submission.status === "approved" ? (
                          <CheckCircle className="h-5 w-5 text-primary" />
                        ) : (
                          <XCircle className="h-5 w-5 text-destructive" />
                        )}
                        <div>
                          <p className="font-medium">{submission.venue.name}</p>
                          <p className="text-sm text-muted-foreground">
                            {submission.status === "approved" ? "Approved" : "Rejected"} by {submission.reviewedBy}
                          </p>
                        </div>
                      </div>
                      <span className="text-sm text-muted-foreground">
                        {submission.reviewedAt &&
                          new Date(submission.reviewedAt).toLocaleDateString("en-US", {
                            month: "short",
                            day: "numeric",
                          })}
                      </span>
                    </CardContent>
                  </Card>
                ))}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="venues" className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-semibold">All Venues</h2>
            <Badge variant="secondary">{mockVenues.length} total</Badge>
          </div>

          <div className="space-y-3">
            {mockVenues.map((venue) => (
              <Card key={venue.id}>
                <CardContent className="flex items-center justify-between p-4">
                  <div className="flex items-center gap-4">
                    <div className="relative h-16 w-16 overflow-hidden rounded-lg">
                      <img
                        src={venue.imageUrl || "/placeholder.svg"}
                        alt={venue.name}
                        className="h-full w-full object-cover"
                      />
                    </div>
                    <div>
                      <p className="font-medium">{venue.name}</p>
                      <p className="text-sm text-muted-foreground">
                        {venue.category} • {venue.city}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <p className="text-sm font-medium">{venue.rating} ★</p>
                      <p className="text-xs text-muted-foreground">{venue.reviewCount} reviews</p>
                    </div>
                    <button className="rounded-lg border border-border bg-transparent px-3 py-1.5 text-sm font-medium text-foreground transition-colors hover:bg-muted">
                      Edit
                    </button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="events" className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-semibold">All Events</h2>
            <Badge variant="secondary">{mockEvents.length} upcoming</Badge>
          </div>

          <div className="space-y-3">
            {mockEvents.map((event) => (
              <Card key={event.id}>
                <CardContent className="flex items-center justify-between p-4">
                  <div className="flex items-center gap-4">
                    <div className="relative h-16 w-16 overflow-hidden rounded-lg">
                      <img
                        src={event.imageUrl || "/placeholder.svg"}
                        alt={event.name}
                        className="h-full w-full object-cover"
                      />
                    </div>
                    <div>
                      <p className="font-medium">{event.name}</p>
                      <p className="text-sm text-muted-foreground">
                        {event.venueName} •{" "}
                        {new Date(event.date).toLocaleDateString("en-US", {
                          month: "short",
                          day: "numeric",
                        })}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <p className="text-sm font-medium">
                        {event.registered}/{event.capacity}
                      </p>
                      <p className="text-xs text-muted-foreground">registered</p>
                    </div>
                    <button className="rounded-lg border border-border bg-transparent px-3 py-1.5 text-sm font-medium text-foreground transition-colors hover:bg-muted">
                      Edit
                    </button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
