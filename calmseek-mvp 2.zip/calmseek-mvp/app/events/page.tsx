import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Calendar, Clock, MapPin, Users, Volume2, Sun } from "lucide-react"
import { mockEvents } from "@/lib/mock-data"
import Link from "next/link"

export default function EventsPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="mb-3 text-4xl font-bold tracking-tight text-foreground">Sensory-Friendly Events</h1>
        <p className="max-w-2xl text-lg text-muted-foreground text-pretty">
          Discover upcoming events designed with sensory considerations in mind. Small groups, calm environments, and
          flexible participation.
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {mockEvents.map((event) => (
          <Card key={event.id} className="flex flex-col">
            <div className="relative aspect-video overflow-hidden rounded-t-lg">
              <img src={event.imageUrl || "/placeholder.svg"} alt={event.name} className="h-full w-full object-cover" />
            </div>
            <CardHeader>
              <CardTitle className="text-lg text-balance">{event.name}</CardTitle>
              <CardDescription className="space-y-1">
                <div className="flex items-center gap-1 text-sm">
                  <MapPin className="h-3 w-3" />
                  {event.venueName}
                </div>
                <div className="flex items-center gap-1 text-sm">
                  <Calendar className="h-3 w-3" />
                  {new Date(event.date).toLocaleDateString("en-US", {
                    weekday: "short",
                    month: "short",
                    day: "numeric",
                  })}
                </div>
                <div className="flex items-center gap-1 text-sm">
                  <Clock className="h-3 w-3" />
                  {event.time}
                </div>
              </CardDescription>
            </CardHeader>
            <CardContent className="flex-1 space-y-4">
              <p className="text-sm text-muted-foreground line-clamp-3">{event.description}</p>

              {/* Sensory Attributes */}
              <div className="flex flex-wrap gap-2">
                <Badge variant="outline" className="gap-1 text-xs">
                  <Volume2 className="h-3 w-3" />
                  {event.sensoryAttributes.noiseLevel}
                </Badge>
                <Badge variant="outline" className="gap-1 text-xs">
                  <Sun className="h-3 w-3" />
                  {event.sensoryAttributes.lighting}
                </Badge>
                <Badge variant="outline" className="gap-1 text-xs">
                  <Users className="h-3 w-3" />
                  {event.registered}/{event.capacity}
                </Badge>
              </div>

              {/* Tags */}
              <div className="flex flex-wrap gap-1">
                {event.tags.map((tag) => (
                  <Badge key={tag} variant="secondary" className="text-xs">
                    {tag}
                  </Badge>
                ))}
              </div>

              <Button className="w-full" asChild>
                <Link href={`/events/${event.id}`}>View Details</Link>
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
